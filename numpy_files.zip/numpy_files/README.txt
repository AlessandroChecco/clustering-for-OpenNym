R=P^T Utilde^T V
